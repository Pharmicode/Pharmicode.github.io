# Drug Shortage Operations

Open **Drug Shortage Operations.pbip** in a compatible Power BI Desktop installation. Use Refresh to load the embedded snapshot if needed. No Excel or external database connector is required.

The snapshot is rebuilt by the project pipeline; Refresh alone does not reread CSV files. Definitions, field references, and canvas bounds are checked programmatically. Power BI opening, DAX execution, cross-filtering, and rendering are unverified. No screenshots have been fabricated.

Format reference: https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report
