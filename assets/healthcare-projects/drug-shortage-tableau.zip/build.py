"""Deterministic synthetic inventory analysis package; no Tableau workbook is claimed."""
from pathlib import Path
from datetime import date, timedelta
from collections import defaultdict, deque
import csv, json, random, math, hashlib, statistics

ROOT=Path(__file__).resolve().parent
START=date(2025,1,1); END=date(2025,12,31)
SEED=4305

def save_csv(name, rows):
    p=ROOT/'data'/name; p.parent.mkdir(exist_ok=True)
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator="\n");w.writeheader();w.writerows(rows)

def save_json(name,obj):
    p=ROOT/'reports'/name;p.parent.mkdir(exist_ok=True)
    p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')

def build():
    rng=random.Random(SEED);rows=[];orders=[];catalog=[]
    for i in range(12):
        catalog.append(dict(medication_id=f'SYN-M{i+1:02}',medication_name=f'Synthetic item {i+1:02}',category=['Injectable','Oral','Infusion'][i%3],supplier=f'Supplier {1+i%3}',nominal_lead_days=[3,6,9][i%3],unit_cost_cents=250+185*i,base_daily_demand=0 if i==11 else 4+i%5))
    for med in catalog:
        for dep,mult in [('Emergency',1.2),('Medical',1.0),('Surgical',0.8)]:
            base=med['base_daily_demand']*mult
            stock=math.ceil(base*(med['nominal_lead_days']+4));pending=None;trail=deque(maxlen=30)
            for di in range(365):
                d=START+timedelta(days=di);opening=stock;receipt=0;lead_sum=0;receipt_count=0;receipt_cost=0
                cost=round(med['unit_cost_cents']*(1+0.004*(d.month-1)))
                if pending and pending['receipt_date']==d.isoformat():
                    receipt=pending['ordered_units'];lead_sum=pending['actual_lead_days'];receipt_count=1;receipt_cost=pending['purchase_cost_cents'];pending=None
                expected=base*(0.8 if d.weekday()>=5 else 1.05)*(1.12 if d.month in [1,2,12] else 1)
                demand=0 if base==0 else max(0,round(rng.gauss(expected,max(1,base*.32))))
                fulfilled=min(opening+receipt,demand);lost=demand-fulfilled;stock=opening+receipt-fulfilled
                trail.append(demand);adu=sum(trail)/len(trail)
                reorder=math.ceil(adu*(med['nominal_lead_days']+3))
                dos=stock/adu if adu else None
                risk='No demand' if not adu else ('High' if lost or dos<med['nominal_lead_days'] else ('Watch' if dos<med['nominal_lead_days']+3 else 'Routine'))
                row=dict(reporting_date=d.isoformat(),medication_id=med['medication_id'],medication_name=med['medication_name'],category=med['category'],department=dep,supplier=med['supplier'],opening_units=opening,receipt_units=receipt,demand_units=demand,fulfilled_units=fulfilled,unfilled_units=lost,closing_units=stock,avg_daily_demand_30=round(adu,8),demand_window_days=len(trail),nominal_lead_days=med['nominal_lead_days'],reorder_point_units=reorder,days_of_supply=round(dos,8) if dos is not None else '',risk_tier=risk,below_reorder=int(stock<reorder),stockout_event=int(lost>0),unit_cost_cents=cost,inventory_value_cents=stock*cost,receipt_order_count=receipt_count,receipt_lead_days_sum=lead_sum,receipt_cost_cents=receipt_cost)
                rows.append(row)
                if stock<reorder and pending is None:
                    qty=max(1,math.ceil(adu*(med['nominal_lead_days']+16))-stock)
                    actual=med['nominal_lead_days']+rng.choice([0,1,2,3,10 if med['supplier']=='Supplier 3' else 2])
                    pending=dict(purchase_order_id=f'PO-{len(orders)+1:05}',medication_id=med['medication_id'],department=dep,supplier=med['supplier'],order_date=d.isoformat(),receipt_date=(d+timedelta(days=actual)).isoformat(),actual_lead_days=actual,ordered_units=qty,unit_cost_cents=cost,purchase_cost_cents=qty*cost,received_by_reporting_end=int(d+timedelta(days=actual)<=END))
                    orders.append(pending)
    rows.sort(key=lambda r:(r['reporting_date'],r['medication_id'],r['department']))
    save_csv('inventory_daily.csv',rows);save_csv('purchase_orders.csv',orders);save_csv('medications.csv',catalog)
    save_csv('latest_risk.csv',[r for r in rows if r['reporting_date']==END.isoformat()])
    validate()

def validate():
    def read(n):
        with (ROOT/'data'/n).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
    rows=read('inventory_daily.csv');orders=read('purchase_orders.csv');seen=set();groups=defaultdict(list);receipts=defaultdict(lambda:[0,0,0,0])
    for p in orders:
        od=date.fromisoformat(p['order_date']);rd=date.fromisoformat(p['receipt_date'])
        assert (rd-od).days==int(p['actual_lead_days'])>0
        assert int(p['purchase_cost_cents'])==int(p['ordered_units'])*int(p['unit_cost_cents'])
        assert int(p['received_by_reporting_end'])==int(rd<=END)
        if rd<=END:
            t=receipts[(p['medication_id'],p['department'],p['receipt_date'])]
            for j,v in enumerate([int(p['ordered_units']),1,int(p['actual_lead_days']),int(p['purchase_cost_cents'])]):t[j]+=v
    for r in rows:
        k=(r['medication_id'],r['department'],r['reporting_date']);assert k not in seen;seen.add(k)
        op,rec,dem,ful,lost,close=[int(r[x]) for x in ['opening_units','receipt_units','demand_units','fulfilled_units','unfilled_units','closing_units']]
        assert min(op,rec,dem,ful,lost,close)>=0 and op+rec-ful==close and ful+lost==dem and ful==min(op+rec,dem)
        assert [rec,int(r['receipt_order_count']),int(r['receipt_lead_days_sum']),int(r['receipt_cost_cents'])]==receipts[k]
        assert int(r['inventory_value_cents'])==close*int(r['unit_cost_cents'])
        groups[(k[0],k[1])].append(r)
    for g in groups.values():
        assert len(g)==365
        for i,r in enumerate(g):
            if i:assert int(r['opening_units'])==int(g[i-1]['closing_units'])
            window=g[max(0,i-29):i+1];adu=statistics.mean(int(x['demand_units']) for x in window)
            assert abs(float(r['avg_daily_demand_30'])-adu)<1e-7
            assert int(r['demand_window_days'])==len(window)
            rp=math.ceil(adu*(int(r['nominal_lead_days'])+3));assert int(r['reorder_point_units'])==rp
            assert int(r['below_reorder'])==int(int(r['closing_units'])<rp)
            if adu:
                dos=int(r['closing_units'])/adu;assert abs(float(r['days_of_supply'])-dos)<1e-7
                risk='High' if int(r['unfilled_units']) or dos<int(r['nominal_lead_days']) else ('Watch' if dos<int(r['nominal_lead_days'])+3 else 'Routine')
            else:assert r['days_of_supply']=='';risk='No demand'
            assert r['risk_tier']==risk
    # Independent selected-date/filter metrics, not a sum of snapshots across dates.
    cases=[]
    for name,day,dept,supplier,category in [('baseline','2025-12-31',None,None,None),('department','2025-06-30','Emergency',None,None),('supplier','2025-03-31',None,'Supplier 3',None),('category','2025-08-31',None,None,'Oral'),('empty','2026-01-01',None,None,None)]:
        sel=[r for r in rows if r['reporting_date']==day and (dept is None or r['department']==dept) and (supplier is None or r['supplier']==supplier) and (category is None or r['category']==category)]
        cases.append(dict(name=name,as_of_date=day,department=dept,supplier=supplier,category=category,expected=dict(item_locations=len(sel),on_hand_units=sum(int(r['closing_units']) for r in sel),inventory_value_usd=sum(int(r['inventory_value_cents']) for r in sel)/100,below_reorder=sum(int(r['below_reorder']) for r in sel),high_risk=sum(r['risk_tier']=='High' for r in sel))))
    assert any(int(r['unfilled_units']) for r in rows) and any(r['risk_tier']=='No demand' for r in rows)
    assert len(rows)==13140 and len(groups)==36
    save_json('validation.json',dict(all_passed=True,seed=SEED,daily_rows=len(rows),item_locations=len(groups),purchase_orders=len(orders),checks=['unique grain','365 days per item/location','continuous stock ledger','nonnegative quantities','demand fulfillment identity','receipt and PO reconciliation','receipt chronology and cost','trailing demand independent mean','reorder point and risk thresholds','zero demand null supply','snapshot filter cases'],tableau_calculations_tested=False,tableau_rendering_verified=False))
    save_json('tableau_acceptance_cases.json',cases)
    baseline=cases[0]['expected'];demand=sum(int(r['demand_units']) for r in rows);lost=sum(int(r['unfilled_units']) for r in rows)
    suppliers={s:statistics.mean(int(p['actual_lead_days']) for p in orders if p['supplier']==s and int(p['received_by_reporting_end'])) for s in sorted({p['supplier'] for p in orders})}
    metrics=dict(**baseline,annual_demand=demand,annual_unfilled_units=lost,unit_fill_rate=1-lost/demand,stockout_item_days=sum(int(r['stockout_event']) for r in rows),observed_received_po_lead_days=suppliers)
    save_json('metrics.json',metrics)
    save_json('data_manifest.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'data').glob('*.csv'))})
    write_docs(metrics)
    print(json.dumps(metrics))

def write_docs(m):
    (ROOT/'docs').mkdir(exist_ok=True)
    (ROOT/'README.md').write_text(f'''# Drug shortage and inventory risk analytics

**Status: blocked for Tableau authoring and application validation.** Analysis-ready build package only; no tested Tableau dashboard or screenshot is included. Tableau Desktop 2026.2 is installed, but this session exposes no Computer Use node_repl control tool. Data, calculations, instructions, acceptance cases, and wireframe are prepared so authoring can resume directly.

## Business question
Which item/department combinations need purchasing review, and where do delayed receipts increase modeled stockout exposure? Audience: pharmacy purchasing and inventory managers. All items, demand, suppliers, and prices are synthetic. This does not identify verified FDA shortages or recommend medication substitutions.

## Rebuild and review
Run `python build.py` (Python standard library only). It regenerates four CSV files and independent validation reports with seed 4305. Read [data and KPI definitions](docs/DATA_DICTIONARY.md), [Tableau authoring instructions](docs/TABLEAU_BUILD.md), and [calculated fields](docs/CALCULATED_FIELDS.md). `docs/wireframe.svg` is a labeled layout specification, not an application screenshot. Compare desktop results with `reports/tableau_acceptance_cases.json` before changing status.

## Findings and recommendations
- December 31 has {m['item_locations']} item/department combinations holding {m['on_hand_units']:,} units, valued at ${m['inventory_value_usd']:,.2f} at current modeled reference prices. Review value and demand together before reducing holdings.
- {m['below_reorder']} combinations are below their modeled reorder point and {m['high_risk']} are high risk at year end. Triage the high-risk table by days of supply and open orders; a threshold flag is not a purchase authorization.
- Annual unmet demand is {m['annual_unfilled_units']:,} of {m['annual_demand']:,} requested units, a {m['unit_fill_rate']:.1%} unit fill rate. Review purchase timing and demand variability rather than treating lost requests as zero demand.
- There are {m['stockout_item_days']:,} item/department/days with unmet demand. The trailing demand denominator includes unmet requests, avoiding understated demand after a stockout.
- Mean received-order lead times are {', '.join(f'{s}: {v:.1f} days' for s,v in m['observed_received_po_lead_days'].items())}. Compare these with nominal policy lead times before a simulated safety-stock change; differences are generated assumptions, not actual supplier performance.

## Limits
No expiry, lots, substitution, transfers, backorders, clinical criticality, or validated demand forecast. Unmet demand is lost, not carried forward. Daily inventory value uses current reference cost, not accounting FIFO. A stockout event means unmet demand during a day, not every zero closing balance. January averages use available history up to 30 days. Purchase orders may arrive after year end and are excluded from received totals until then. Desktop calculated fields, filter interactions, file portability, and visual rendering remain untested.
''',encoding='utf-8')

if __name__=='__main__':build()
