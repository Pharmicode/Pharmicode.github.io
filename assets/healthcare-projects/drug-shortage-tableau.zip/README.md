# Drug shortage and inventory risk analytics

**Status: blocked for Tableau authoring and application validation.** Analysis-ready build package only; no tested Tableau dashboard or screenshot is included. Tableau Desktop 2026.2 is installed, but this session exposes no Computer Use node_repl control tool. Data, calculations, instructions, acceptance cases, and wireframe are prepared so authoring can resume directly.

## Business question
Which item/department combinations need purchasing review, and where do delayed receipts increase modeled stockout exposure? Audience: pharmacy purchasing and inventory managers. All items, demand, suppliers, and prices are synthetic. This does not identify verified FDA shortages or recommend medication substitutions.

## Rebuild and review
Run `python build.py` (Python standard library only). It regenerates four CSV files and independent validation reports with seed 4305. Read [data and KPI definitions](docs/DATA_DICTIONARY.md), [Tableau authoring instructions](docs/TABLEAU_BUILD.md), and [calculated fields](docs/CALCULATED_FIELDS.md). `docs/wireframe.svg` is a labeled layout specification, not an application screenshot. Compare desktop results with `reports/tableau_acceptance_cases.json` before changing status.

## Findings and recommendations
- December 31 has 36 item/department combinations holding 1,701 units, valued at $21,915.35 at current modeled reference prices. Review value and demand together before reducing holdings.
- 20 combinations are below their modeled reorder point and 13 are high risk at year end. Triage the high-risk table by days of supply and open orders; a threshold flag is not a purchase authorization.
- Annual unmet demand is 1,736 of 70,873 requested units, a 97.6% unit fill rate. Review purchase timing and demand variability rather than treating lost requests as zero demand.
- There are 331 item/department/days with unmet demand. The trailing demand denominator includes unmet requests, avoiding understated demand after a stockout.
- Mean received-order lead times are Supplier 1: 4.6 days, Supplier 2: 7.6 days, Supplier 3: 11.9 days. Compare these with nominal policy lead times before a simulated safety-stock change; differences are generated assumptions, not actual supplier performance.

## Limits
No expiry, lots, substitution, transfers, backorders, clinical criticality, or validated demand forecast. Unmet demand is lost, not carried forward. Daily inventory value uses current reference cost, not accounting FIFO. A stockout event means unmet demand during a day, not every zero closing balance. January averages use available history up to 30 days. Purchase orders may arrive after year end and are excluded from received totals until then. Desktop calculated fields, filter interactions, file portability, and visual rendering remain untested.
