# Data dictionary and KPI definitions

All CSVs are UTF-8 with headers. Dates are ISO YYYY-MM-DD; all currency source values are integer US cents. Quantities refer to consistent modeled units within each synthetic item, not clinical dosing units. Reporting period: calendar 2025.

## Files and grain
| File | Grain / key | Use |
|---|---|---|
| inventory_daily.csv | reporting_date + medication_id + department; 13,140 rows | Main Tableau source. Contains all descriptive fields; no join needed |
| latest_risk.csv | medication_id + department on 2025-12-31; 36 rows | Convenience export; do not append to daily history |
| purchase_orders.csv | purchase_order_id | Audit and open-order detail, independent source |
| medications.csv | medication_id; 12 rows | Reference dictionary; synthetic names and categories |

## Daily fields
| Fields | Definition / type |
|---|---|
| reporting_date | End-of-day snapshot date |
| medication_id, medication_name | Invented operational identifier and display name; no NDC/RxNorm assertion |
| category, department, supplier | Synthetic labels, dimension strings |
| opening_units | Prior day's closing units; January 1 initial stock is modeled |
| receipt_units | PO units received that morning |
| demand_units | New requested units that day, including unmet requests |
| fulfilled_units | min(opening + receipts, demand) |
| unfilled_units | demand - fulfilled; lost rather than backlogged |
| closing_units | opening + receipts - fulfilled; never negative |
| avg_daily_demand_30 | Mean of requested units over current and previous 29 available dates; not fulfilled usage |
| demand_window_days | 1–30 available dates in the trailing window |
| nominal_lead_days | Synthetic nominal supplier lead time: 3, 6, or 9 calendar days |
| reorder_point_units | ceiling(avg daily demand * (nominal lead days + 3 safety days)) |
| days_of_supply | closing / average daily demand; blank when average is zero |
| below_reorder | Integer 1 when closing < reorder point, else 0 |
| stockout_event | Integer 1 when unfilled units > 0 that day; item/location/day event |
| risk_tier | No demand if average=0; otherwise High if unmet demand or supply < nominal lead; Watch if supply < nominal lead+3; Routine otherwise |
| unit_cost_cents | Current modeled reference price; monthly 0.4% step from baseline, rounded to cents |
| inventory_value_cents | closing * current reference unit cost; not historical inventory accounting |
| receipt_order_count | Number of received POs (0 or 1 at this grain) |
| receipt_lead_days_sum | Sum of actual calendar lead days of those POs |
| receipt_cost_cents | Received quantity * PO order-date unit price |

## Purchase and reference fields
PO: purchase_order_id, medication_id, department, supplier, order_date, receipt_date, actual_lead_days (receipt minus order), ordered_units, unit_cost_cents (fixed at placement), purchase_cost_cents (quantity*price), received_by_reporting_end (receipt <= 2025-12-31). An order is placed after daily demand when below reorder and no existing PO remains; quantity covers modeled lead time + 16 days less current stock. Actual lead includes synthetic delay. Orders are not duplicated as receipts.

Reference: medication_id/name/category/supplier/nominal_lead_days/unit_cost_cents/base_daily_demand. Base demand is modulated by department, weekend, winter, and random variation; item 12 deliberately has no demand to test undefined supply.

## Safe aggregation
Snapshot on-hand/value/below-reorder/high-risk use **one selected date**. Count item/location combinations, not unique medications. Do not sum stock balances across dates. Trend stock is summed across item/locations per date. Demand/fulfilled/unfilled and receipt amounts may be summed across dates. Period fill rate = SUM(fulfilled)/SUM(demand), null for zero demand. Received PO mean lead = SUM(receipt_lead_days_sum)/SUM(receipt_order_count), null for no receipts. Do not average daily averages. Days of supply is an item/location measure; never sum it across items. Risk flags describe generated operational thresholds rather than verified real-world shortage status.
