# Proposed Tableau calculated fields

These formulas are prepared for desktop entry and have **not executed in Tableau**. Preserve lowercase CSV field names. Set date columns to Date, IDs to String, quantities/cents to Number (whole), and average demand/supply to Number (decimal). Empty supply imports as null. Parameters: `As of Date` Date default 2025-12-31, allowable range 2025-01-01–2025-12-31; `History Start` Date default 2025-01-01. Validate or reject reversed ranges; do not silently swap dates.

Create each field separately in the main daily source:

```tableau
// Snapshot Row
[reporting_date] = [As of Date]
```
```tableau
// History Row
[reporting_date] >= [History Start] AND [reporting_date] <= [As of Date]
```
```tableau
// Snapshot On Hand
SUM(IF [Snapshot Row] THEN [closing_units] ELSE 0 END)
```
```tableau
// Snapshot Inventory USD
SUM(IF [Snapshot Row] THEN [inventory_value_cents] ELSE 0 END) / 100.0
```
```tableau
// Snapshot Below Reorder
SUM(IF [Snapshot Row] THEN [below_reorder] ELSE 0 END)
```
```tableau
// Snapshot High Risk
SUM(IF [Snapshot Row] AND [risk_tier] = 'High' THEN 1 ELSE 0 END)
```
```tableau
// Snapshot Item Locations
SUM(IF [Snapshot Row] THEN 1 ELSE 0 END)
```
```tableau
// Item Days of Supply (row level; show ATTR at item/location/date grain)
IF [avg_daily_demand_30] > 0 THEN [closing_units] / [avg_daily_demand_30] END
```
```tableau
// Unit Fill Rate (apply History Row = True)
IF SUM([demand_units]) > 0 THEN SUM([fulfilled_units]) / SUM([demand_units]) END
```
```tableau
// Received PO Mean Lead Days (apply History Row = True)
IF SUM([receipt_order_count]) > 0 THEN SUM([receipt_lead_days_sum]) / SUM([receipt_order_count]) END
```
```tableau
// Weighted Received Unit Cost USD (apply History Row = True)
IF SUM([receipt_units]) > 0 THEN SUM([receipt_cost_cents]) / SUM([receipt_units]) / 100.0 END
```

For trends, date is on the view: SUM(closing_units), SUM(inventory_value_cents)/100, SUM(unfilled_units). Unit cost across heterogeneous items is not a price index; use item/department selection for cost trend interpretation. Use dimension filters for category/department/supplier on all daily-source worksheets. Do not apply Snapshot Row globally: doing so destroys historical trends. A risk-tier selection applies to the snapshot risk table only unless an explicitly tested item/location dashboard action selects histories.

References for authoring conventions: [Tableau date functions](https://help.tableau.com/current/pro/desktop/en-us/functions_functions_date.htm) and [data model / aggregation](https://help.tableau.com/current/pro/desktop/en-us/datasource_datamodel.htm). No physical multi-fact join is needed in this package.
