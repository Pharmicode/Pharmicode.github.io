# Tableau authoring and acceptance plan

**Blocked:** no callable Computer Use node_repl tool in this session. Installation at Tableau 2026.2 was verified, but licensing, workbook opening, calculations, and rendered dashboards were not tested. No TWB/TWBX is supplied and no image is represented as a screenshot.

## Build
1. Open Tableau Desktop and connect Text File to `data/inventory_daily.csv`. Leave it as one logical table. Set data types per CALCULATED_FIELDS.md and check 13,140 records. Do not join latest_risk or POs onto it.
2. Enter the two date parameters and calculated fields exactly as specified. Show parameters and category/department/supplier dropdowns. Default all dimensions to All. Clear worksheet selections when changing as-of date.
3. Build KPI sheets for snapshot on-hand, inventory USD, below reorder, high risk, item locations, plus history unit fill rate. Label High Risk as **modeled risk**.
4. History Stock: reporting_date continuous day, SUM(closing_units), History Row=True. Add daily reference inventory value USD in a separate companion tooltip, not as a units axis. History Unmet: daily SUM(unfilled_units), same history filter.
5. Supplier Lead: supplier and Received PO Mean Lead Days, history filter. Include received-order count in tooltip. Price Trend: reporting_date week and Weighted Received Unit Cost USD; item/department filters strongly recommended because changing mix affects the mean.
6. Risk Queue: filter Snapshot Row=True; show item, department, supplier, closing, average daily demand, ATTR(Item Days of Supply), reorder point, risk tier. Color High muted red, Watch amber, Routine teal, No demand gray. Sort risk then days of supply; null supply displays “No demand,” never zero.
7. Dashboard fixed 1400x900, white background, navy #17324D, teal #12858A, readable 12pt minimum. Use docs/wireframe.svg as a layout specification. Add parameter/filter row, six KPI tiles, trends, supplier comparison, and full-width risk queue. Tooltips show date, units, trailing-window length, synthetic source, and nominal vs observed lead meaning.
8. Optional risk-row selection action filters trends by both medication_id and department. Clearing selection restores all rows. Test combined dimensions and parameter changes before enabling action. Keep supplier lead means on the selected scope and explain when no receipts exist.
9. Save `drug_shortage_inventory_risk.twbx` with embedded CSV sources inside this folder. Reopen it from a temporary local copy and verify no absolute-source-path dependency. Do not publish to Tableau Public.

## Acceptance checklist
- Reconcile five snapshot scenarios against `reports/tableau_acceptance_cases.json` (the out-of-range case is a developer test; allow a temporary unrestricted date then restore bounds).
- Test January 1 short history, zero-demand item 12 (null supply), day with unmet demand, no received POs in a short period, combined filters returning no rows, and reversed history range (blank history, visible explanatory label).
- Confirm snapshot cards use a single date while trends retain history. Confirm the lead mean is weighted by PO count. Selecting and clearing a risk row must preserve totals and affect the intended item/location.
- Reconcile annual fill rate and stockout item-days against reports/metrics.json with History Start Jan 1 and As of Dec 31.
- Capture actual dashboard screenshots only after desktop checks. Check labels, tooltips, legends, and units at 100% scale. Write results with Tableau version and failed cases to reports/tableau_validation.json. Mark complete only when a working saved/reopened workbook and actual rendering have been reviewed.
