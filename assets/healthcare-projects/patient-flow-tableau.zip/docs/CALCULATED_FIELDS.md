# Proposed Tableau calculations

**Not executed in Tableau yet.** Main source: `daily_capacity_flow.csv`. Set reporting_date to Date, department to String, all count/minute/capacity fields to Number (whole), convenience occupancy/bed-days to Number (decimal). Create `Start Date` and `End Date` Date parameters, defaults Jan 1 and Dec 31, 2025, allowable date range within 2025.

```tableau
// In Selected Period (filter True on every main-source worksheet)
[reporting_date] >= [Start Date] AND [reporting_date] <= [End Date]
```
```tableau
// Admissions
SUM([admissions])
```
```tableau
// Discharges
SUM([discharges])
```
```tableau
// Occupied Bed Days
SUM([occupied_minutes]) / 1440.0
```
```tableau
// Available Bed Days
SUM([capacity_minutes]) / 1440.0
```
```tableau
// Occupancy Rate
IF SUM([capacity_minutes]) > 0 THEN SUM([occupied_minutes]) / SUM([capacity_minutes]) END
```
```tableau
// Completed Mean LOS Days (discharge cohort)
IF SUM([completed_los_count]) > 0 THEN
  SUM([discharged_los_minutes_sum]) / SUM([completed_los_count]) / 1440.0
END
```
```tableau
// Week Starting Monday
DATETRUNC('week', [reporting_date], 'monday')
```
```tableau
// Reporting Month
DATETRUNC('month', [reporting_date])
```
```tableau
// Valid Date Range (parameter-only field; show message independently of fact filters)
[Start Date] <= [End Date]
```

Use a parameter-only status worksheet without the period filter to show reversed-date warning; verify its visibility in desktop. Empty selections show n.a. for rates, and zero event counts only if explicitly formatted as such after native testing. Show weighted occupancy as a percentage with one decimal; LOS as days with two decimals. Tooltips show occupied bed-days, available bed-days, and discharges contributing to LOS.

Optional separate encounter source fields (not joined to daily capacity):
```tableau
// Completed Encounter LOS Days
IF NOT ISNULL([discharge_time]) THEN
  DATEDIFF('minute', [admission_time], [discharge_time]) / 1440.0
END
```
Use its discharge date for LOS detail and admission date for admissions detail; do not claim one universal date filter has both meanings. Active encounters retain null discharge/LOS.

Authoring references: [Tableau date functions](https://help.tableau.com/current/pro/desktop/en-us/functions_functions_date.htm), [Tableau data model](https://help.tableau.com/current/pro/desktop/en-us/datasource_datamodel.htm). Core views deliberately use one preaggregated fact to avoid duplicated capacity.
