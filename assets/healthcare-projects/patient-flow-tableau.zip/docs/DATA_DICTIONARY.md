# Patient flow data dictionary and KPI methods

Synthetic period: January 1, 2025 00:00 inclusive through January 1, 2026 00:00 exclusive. ISO dates/timestamps, nominal local hospital clock with 24-hour days; no daylight-saving adjustment. CSV UTF-8. Minute precision; no fractional rounding in occupied-minute totals.

## Encounters: one row per encounter
| Field | Meaning |
|---|---|
| encounter_id | Unique invented SYN-E ID; no actual patient identifier |
| department | Medical, Surgical, Observation; no interdepartment transfers |
| bed_id | Unique department-specific bed: 20 Medical, 14 Surgical, 12 Observation |
| admission_time | Actual synthetic arrival into that bed; may precede 2025 for carry-in |
| discharge_time | Completed discharge strictly before period end; blank for active encounters at cutoff |
| admission_type | Emergency / Elective / Transfer; Transfer means admission from outside this modeled hospital |
| discharge_disposition | Home / Skilled nursing / Transfer / Died; Still admitted if censored |
| completed_los_minutes | Full admission-to-discharge duration, including pre-period time for carry-in discharges; blank if active at cutoff |
| carry_in | 1 if admitted before Jan 1 and still present at start |
| censored_at_period_end | 1 if no observed discharge before end; future discharge and completed LOS deliberately withheld |
| observed_period_minutes | Duration intersecting reporting period; never eventual LOS for censored records |

Schedules are generated from November 2024 to avoid empty beds at reporting start. Fully pre-period encounters are excluded. Lognormal LOS differs by department with winter modulation; exponentially distributed gaps separate stays. No bed can contain overlapping encounters. This models occupancy, not unmet demand or an optimal capacity plan.

## Daily capacity/flow: one row per date + department
| Field | Meaning / aggregation |
|---|---|
| reporting_date, department | Unique composite key; 365 dates x 3 departments = 1,095 rows |
| available_beds | Constant modeled service capacity on that date; do not sum this across dates as a bed count |
| capacity_minutes | available_beds * 1,440; additive denominator |
| occupied_minutes | Sum of encounter overlap with [day midnight, next midnight), capped to period; additive |
| admissions | Encounters whose admission timestamp falls on this date; excludes carry-in |
| discharges | Observed discharges on this date; excludes year-end active encounters |
| discharged_los_minutes_sum | Full LOS minutes of encounters discharged on this date, including carry-in |
| completed_los_count | Number contributing to LOS numerator; equals discharges in this model |
| carry_in_occupied_minutes | Subset of occupied minutes from encounters admitted before reporting start |
| occupancy_rate | Daily occupied_minutes / capacity_minutes; convenience check only, not a measure to average across services |
| occupied_bed_days | Daily occupied_minutes / 1,440; additive exposure, can be fractional |

## KPI denominators and date scope
- Occupancy = SUM(occupied_minutes)/SUM(capacity_minutes) for selected service dates and departments; null if no capacity. A hospital rate is weighted by available capacity, not the average of department percentages.
- Occupied bed-days = SUM(occupied_minutes)/1,440. Available bed-days = SUM(capacity_minutes)/1,440. Bed-day rates use interval exposure, not midnight census or count of any patient touching a day.
- Admissions/discharges are event counts in the selected date range. They are different cohorts and need not be equal. Annual opening patients + admissions - discharges = closing patients.
- Mean completed LOS days = SUM(discharged_los_minutes_sum)/SUM(completed_los_count)/1,440. Uses **discharge cohort** selected by discharge date, not admission date. Include carry-in if discharged in range; omit active stays from completed LOS. Zero discharges => null.
- Utilization and LOS aggregations must use the daily fact exactly once. Do not join encounter rows onto capacity: that would multiply the denominator. Detail source is separate and has its own explicit admission/discharge filtering semantics.
- Weekly trends use Monday week starts; partial first/last weeks use only available selected days. Monthly rates are ratios of sums, not averages of daily percentages.
