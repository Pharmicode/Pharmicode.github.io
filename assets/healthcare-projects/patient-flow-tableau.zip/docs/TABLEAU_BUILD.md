# Tableau build and validation plan

Status: **blocked** for desktop authoring. Tableau 2026.2 is installed but supported Computer Use node_repl control is unavailable in this active session. Licensing and desktop operations remain unverified. No tested TWB/TWBX or actual screenshots are included.

1. Open Tableau Desktop and connect to `data/daily_capacity_flow.csv` as a single logical table. Confirm 1,095 rows and correct types. Do not physically join encounters to this table.
2. Create date parameters and calculated fields from CALCULATED_FIELDS.md. Apply In Selected Period=True and department multi-select to every main-source sheet. Use all departments, all 2025 by default.
3. Create five KPI tiles: admissions, discharges, completed mean LOS days, occupancy rate, occupied bed-days. Clearly label LOS “discharge cohort.” Add available bed-days to occupancy tooltip and summary footer.
4. Create monthly admissions/discharges lines using Reporting Month and summed event counts. Create monthly LOS using Completed Mean LOS Days (ratio of sums), not AVG of daily LOS. Set units to days.
5. Create daily Occupancy Rate line, 0–100% axis, department color when selected. Add optional 85% reference line labeled “illustrative review marker; not a clinical standard.” No inferred safety threshold.
6. Create department comparison table: admissions, discharges, occupancy %, LOS days, occupied/available bed-days. Create Monday-week x weekday heatmap using Occupancy Rate, with explicit partial-week note. Use date/day on marks so selected-date capacity is counted only once.
7. Dashboard fixed 1400x950, white/light gray, navy #17324D, blue #2878B5, teal #12858A; readable labels and legends. Follow the labeled wireframe. Filters remain at top; give line axes units and date scope. Tooltips include denominator and synthetic source.
8. Optional department selection action filters all core charts and clears back to all. Do not add encounter drill-down until its independent date semantics are shown. If added, connect encounters as a separate source and validate detail counts before enabling cross-source actions.
9. Save `patient_flow_capacity.twbx` with embedded CSV data. Reopen a copy from another local directory, check portability, default filters, and full-year KPIs. No public publication is authorized.

## Desktop acceptance
- Compare the six scopes in reports/tableau_acceptance_cases.json with displayed values, using a temporary unrestricted date only for the out-of-range case; restore parameter bounds afterwards.
- Full year: reconcile reports/metrics.json, including the opening + admissions - discharges = closing identity. The daily fact intentionally excludes opening/closing stock from flow counts.
- Check Jan 1 carry-in, Dec 31 active stays, same-day stays, empty department/date combinations, and reversed dates. Empty rates must be n.a., not zero. Dates outside bounds should be rejected after testing.
- Check monthly/weekly rates against ratios of summed minutes, not averaged precomputed rates. Filter one department then clear it; compare cards and all charts. Inspect partial weeks at both year boundaries.
- Check 0–100% occupancy scale, LOS units and discharge-cohort label, tooltip denominators, and readability at 100% zoom.
- Capture actual desktop screenshots and write reports/tableau_validation.json with version, tests, results, and remaining issues. Mark complete only after saved/reopened workbook behavior and actual rendered dashboard pass review.
