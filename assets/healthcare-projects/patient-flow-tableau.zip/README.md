# Hospital patient flow and capacity analytics

**Status: blocked for Tableau authoring and application validation.** The analysis-ready data, calculation specification, layout wireframe, instructions, and acceptance values are delivered. No tested Tableau workbook or actual dashboard screenshots are included. Tableau 2026.2 is installed; this session lacks the supported Computer Use node_repl control tool.

## Purpose
For hospital operations managers: compare admissions, discharges, completed length of stay, and capacity utilization across Medical, Surgical, and Observation services. Every encounter and bed schedule is synthetic; no real patient information is used.

## Rebuild
Run `python build.py` with Python's standard library (seed 4306). Read [data and KPI definitions](docs/DATA_DICTIONARY.md), [calculated fields](docs/CALCULATED_FIELDS.md), and [authoring instructions](docs/TABLEAU_BUILD.md). Import the prepared daily fact for core dashboards; use encounters separately for drill-down. The SVG wireframe is a specification, not a screenshot. Validation evidence and expected Tableau filter results are in reports/.

## Findings and operational review
- 6,059 admissions and 6,058 discharges occurred during 2025; 38 encounters were already active at the start and 39 remained at year end. These reconcile by patient balance, rather than forcing annual admissions and discharges to match.
- Overall occupancy is 84.7%, using 14,213.2 occupied bed-days / 16,790 available bed-days. Review daily variation before proposing capacity changes; annual means conceal peak days.
- Department occupancy: Medical 91.3%, Surgical 81.9%, Observation 76.8%. Prioritize workflow review in the most consistently occupied service; capacity is modeled, not an actual staffing recommendation.
- Mean LOS among 2025 discharges is 2.35 days. Department discharge-cohort LOS: Medical 4.52, Surgical 2.64, Observation 1.12. Compare like services and discharge cohorts before interpreting throughput differences.
- Patients still admitted at year end have no completed LOS assigned. Track them separately when examining long stays, since a discharged-only average omits their eventual duration.

## Limits
One department and one physical bed per encounter; no transfers between units, staffing changes, bed closures, acuity, readmissions, wait-list demand, or causal intervention model. Capacity is constant by department and assumes nominal 24-hour days without daylight-saving adjustment. Bed schedules prevent concurrent patients in one bed. Admissions and LOS differences are generated, so the results demonstrate methods rather than institutional performance. Desktop formulas, interactions, workbook portability, and rendering remain untested.
