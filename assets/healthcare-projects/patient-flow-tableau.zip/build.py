"""Synthetic bed schedules and additive daily facts, standard-library only."""
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict
import random, math, csv, json, hashlib, calendar

ROOT=Path(__file__).resolve().parent
START=datetime(2025,1,1);STOP=datetime(2026,1,1);SEED=4306
DEPTS={'Medical':(20,4.4,10),'Surgical':(14,2.6,14),'Observation':(12,1.1,8)}

def csv_save(name,rows):
    p=ROOT/'data'/name;p.parent.mkdir(exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator="\n");w.writeheader();w.writerows(rows)

def json_save(name,obj):
    p=ROOT/'reports'/name;p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')

def dt(s):return datetime.fromisoformat(s)

def build():
    rng=random.Random(SEED);enc=[];daily={}
    for dep,(beds,mean_los,gap) in DEPTS.items():
        for day in range(365):
            d=START+timedelta(days=day)
            daily[(dep,d.date())]=dict(reporting_date=d.date().isoformat(),department=dep,available_beds=beds,capacity_minutes=beds*1440,occupied_minutes=0,admissions=0,discharges=0,discharged_los_minutes_sum=0,completed_los_count=0,carry_in_occupied_minutes=0)
        for bed in range(1,beds+1):
            t=datetime(2024,11,1)+timedelta(minutes=rng.randrange(1440))
            while t<STOP:
                sigma=.55;factor=1.12 if t.month in [1,2,12] else 1
                minutes=max(120,round(rng.lognormvariate(math.log(mean_los*1440*factor)-sigma*sigma/2,sigma)))
                discharge=t+timedelta(minutes=minutes)
                if discharge>START:
                    completed=discharge<STOP
                    r=dict(encounter_id=f'SYN-E{len(enc)+1:05}',department=dep,bed_id=f'{dep[:3].upper()}-{bed:02}',admission_time=t.isoformat(sep=' '),discharge_time=discharge.isoformat(sep=' ') if completed else '',admission_type=rng.choices(['Emergency','Elective','Transfer'],[65 if dep!='Surgical' else 20,20 if dep!='Surgical' else 65,15])[0],discharge_disposition=rng.choices(['Home','Skilled nursing','Transfer','Died'],[80,12,7,1])[0] if completed else 'Still admitted',completed_los_minutes=minutes if completed else '',carry_in=int(t<START),censored_at_period_end=int(not completed),observed_period_minutes=round((min(discharge,STOP)-max(t,START)).total_seconds()/60))
                    enc.append(r)
                    if START<=t<STOP:daily[(dep,t.date())]['admissions']+=1
                    if completed:
                        x=daily[(dep,discharge.date())];x['discharges']+=1;x['completed_los_count']+=1;x['discharged_los_minutes_sum']+=minutes
                    cursor=max(t,START)
                    while cursor<min(discharge,STOP):
                        nextday=datetime.combine(cursor.date()+timedelta(days=1),datetime.min.time())
                        segment_end=min(discharge,STOP,nextday);segment=round((segment_end-cursor).total_seconds()/60)
                        x=daily[(dep,cursor.date())];x['occupied_minutes']+=segment
                        if t<START:x['carry_in_occupied_minutes']+=segment
                        cursor=segment_end
                t=discharge+timedelta(minutes=max(30,round(rng.expovariate(1/(gap*60)))))
    rows=sorted(daily.values(),key=lambda r:(r['reporting_date'],r['department']))
    for r in rows:
        r['occupancy_rate']=round(r['occupied_minutes']/r['capacity_minutes'],10)
        r['occupied_bed_days']=round(r['occupied_minutes']/1440,10)
    enc.sort(key=lambda r:(r['admission_time'],r['encounter_id']))
    csv_save('encounters.csv',enc);csv_save('daily_capacity_flow.csv',rows)
    validate()

def validate():
    def read(n):
        with (ROOT/'data'/n).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
    enc=read('encounters.csv');rows=read('daily_capacity_flow.csv');beds=defaultdict(list);ids=set();expected=defaultdict(lambda:dict(occupied_minutes=0,admissions=0,discharges=0,discharged_los_minutes_sum=0,completed_los_count=0,carry_in_occupied_minutes=0))
    for e in enc:
        assert e['encounter_id'] not in ids;ids.add(e['encounter_id'])
        admit=dt(e['admission_time']);exit=dt(e['discharge_time']) if e['discharge_time'] else STOP
        assert admit<exit and exit<=STOP
        assert int(e['carry_in'])==int(admit<START) and int(e['censored_at_period_end'])==int(not e['discharge_time'])
        assert bool(e['completed_los_minutes'])==bool(e['discharge_time'])
        if e['discharge_time']:assert int(e['completed_los_minutes'])==round((exit-admit).total_seconds()/60)
        beds[e['bed_id']].append((admit,exit))
        # Independent calendar intersection, rather than the generator's segment cursor.
        per_total=0
        for day in range(365):
            a=START+timedelta(days=day);b=a+timedelta(days=1);k=(a.date().isoformat(),e['department'])
            overlap=max(0,round((min(exit,b)-max(admit,a)).total_seconds()/60))
            if overlap:
                expected[k]['occupied_minutes']+=overlap;per_total+=overlap
                if admit<START:expected[k]['carry_in_occupied_minutes']+=overlap
        assert per_total==int(e['observed_period_minutes'])
        if START<=admit<STOP:expected[(admit.date().isoformat(),e['department'])]['admissions']+=1
        if e['discharge_time']:
            k=(exit.date().isoformat(),e['department']);expected[k]['discharges']+=1;expected[k]['completed_los_count']+=1;expected[k]['discharged_los_minutes_sum']+=int(e['completed_los_minutes'])
    for intervals in beds.values():
        intervals.sort()
        assert all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:]))
    seen=set()
    for r in rows:
        k=(r['reporting_date'],r['department']);assert k not in seen;seen.add(k)
        assert int(r['available_beds'])==DEPTS[r['department']][0]
        assert int(r['capacity_minutes'])==int(r['available_beds'])*1440
        assert 0<=int(r['occupied_minutes'])<=int(r['capacity_minutes'])
        assert abs(float(r['occupancy_rate'])-int(r['occupied_minutes'])/int(r['capacity_minutes']))<1e-9
        assert abs(float(r['occupied_bed_days'])-int(r['occupied_minutes'])/1440)<1e-9
        assert all(int(r[field])==n for field,n in expected[k].items())
    assert len(rows)==1095 and len(seen)==1095 and len(beds)==46
    assert sum(int(e['observed_period_minutes']) for e in enc)==sum(int(r['occupied_minutes']) for r in rows)
    carry=sum(int(e['carry_in']) for e in enc);active=sum(int(e['censored_at_period_end']) for e in enc)
    admissions=sum(int(r['admissions']) for r in rows);discharges=sum(int(r['discharges']) for r in rows)
    assert carry+admissions-discharges==active
    # Exact boundary fixtures for interval allocation and censoring.
    overlap=lambda a,b,lo,hi:max(0,(min(b,hi)-max(a,lo)).total_seconds()/60)
    assert overlap(datetime(2024,12,31,23),datetime(2025,1,1,1),START,START+timedelta(days=1))==60
    assert overlap(START-timedelta(days=1),START,START,START+timedelta(days=1))==0
    assert overlap(STOP-timedelta(hours=1),STOP+timedelta(hours=5),STOP-timedelta(days=1),STOP)==60
    assert overlap(START+timedelta(hours=10),START+timedelta(hours=12),START,START+timedelta(days=1))==120
    cases=[]
    for name,lo,hi,dep in [('baseline','2025-01-01','2025-12-31',None),('medical_january','2025-01-01','2025-01-31','Medical'),('observation_q2','2025-04-01','2025-06-30','Observation'),('one_day','2025-12-31','2025-12-31','Surgical'),('empty','2026-01-01','2026-01-31',None),('reversed','2025-12-31','2025-01-01',None)]:
        sel=[r for r in rows if lo<=r['reporting_date']<=hi and (dep is None or r['department']==dep)]
        occ=sum(int(r['occupied_minutes']) for r in sel);cap=sum(int(r['capacity_minutes']) for r in sel);count=sum(int(r['completed_los_count']) for r in sel);los=sum(int(r['discharged_los_minutes_sum']) for r in sel)
        cases.append(dict(name=name,start_date=lo,end_date=hi,department=dep,expected=dict(admissions=sum(int(r['admissions']) for r in sel),discharges=sum(int(r['discharges']) for r in sel),occupied_bed_days=occ/1440,available_bed_days=cap/1440,occupancy_rate=occ/cap if cap else None,discharge_cohort_mean_los_days=los/count/1440 if count else None)))
    json_save('tableau_acceptance_cases.json',cases)
    departments={dep:dict(occupancy_rate=sum(int(r['occupied_minutes']) for r in rows if r['department']==dep)/sum(int(r['capacity_minutes']) for r in rows if r['department']==dep),mean_los_days=sum(int(r['discharged_los_minutes_sum']) for r in rows if r['department']==dep)/sum(int(r['completed_los_count']) for r in rows if r['department']==dep)/1440) for dep in DEPTS}
    metrics=dict(**cases[0]['expected'],encounters=len(enc),carry_in_encounters=carry,active_at_end=active,department_metrics=departments)
    json_save('metrics.json',metrics)
    json_save('validation.json',dict(all_passed=True,seed=SEED,encounter_rows=len(enc),daily_rows=len(rows),beds=46,checks=['unique encounter IDs','unique date/department grain','bed schedule non-overlap','admission/discharge chronology','censored records have no future discharge or completed LOS','exact daily interval intersection independent reconstruction','occupied minutes within capacity','admission and discharge count reconciliation','LOS numerator and denominator reconciliation','carry-in + admissions - discharges = active at end','same-day and midnight/year-end boundary fixtures','six acceptance scopes'],tableau_calculations_tested=False,tableau_rendering_verified=False))
    json_save('data_manifest.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'data').glob('*.csv'))})
    write_readme(metrics)
    print(json.dumps(metrics))

def write_readme(m):
    (ROOT/'README.md').write_text(f'''# Hospital patient flow and capacity analytics

**Status: blocked for Tableau authoring and application validation.** The analysis-ready data, calculation specification, layout wireframe, instructions, and acceptance values are delivered. No tested Tableau workbook or actual dashboard screenshots are included. Tableau 2026.2 is installed; this session lacks the supported Computer Use node_repl control tool.

## Purpose
For hospital operations managers: compare admissions, discharges, completed length of stay, and capacity utilization across Medical, Surgical, and Observation services. Every encounter and bed schedule is synthetic; no real patient information is used.

## Rebuild
Run `python build.py` with Python's standard library (seed 4306). Read [data and KPI definitions](docs/DATA_DICTIONARY.md), [calculated fields](docs/CALCULATED_FIELDS.md), and [authoring instructions](docs/TABLEAU_BUILD.md). Import the prepared daily fact for core dashboards; use encounters separately for drill-down. The SVG wireframe is a specification, not a screenshot. Validation evidence and expected Tableau filter results are in reports/.

## Findings and operational review
- {m['admissions']:,} admissions and {m['discharges']:,} discharges occurred during 2025; {m['carry_in_encounters']} encounters were already active at the start and {m['active_at_end']} remained at year end. These reconcile by patient balance, rather than forcing annual admissions and discharges to match.
- Overall occupancy is {m['occupancy_rate']:.1%}, using {m['occupied_bed_days']:,.1f} occupied bed-days / {m['available_bed_days']:,.0f} available bed-days. Review daily variation before proposing capacity changes; annual means conceal peak days.
- Department occupancy: {', '.join(f'{dep} {v['occupancy_rate']:.1%}' for dep,v in m['department_metrics'].items())}. Prioritize workflow review in the most consistently occupied service; capacity is modeled, not an actual staffing recommendation.
- Mean LOS among 2025 discharges is {m['discharge_cohort_mean_los_days']:.2f} days. Department discharge-cohort LOS: {', '.join(f'{dep} {v['mean_los_days']:.2f}' for dep,v in m['department_metrics'].items())}. Compare like services and discharge cohorts before interpreting throughput differences.
- Patients still admitted at year end have no completed LOS assigned. Track them separately when examining long stays, since a discharged-only average omits their eventual duration.

## Limits
One department and one physical bed per encounter; no transfers between units, staffing changes, bed closures, acuity, readmissions, wait-list demand, or causal intervention model. Capacity is constant by department and assumes nominal 24-hour days without daylight-saving adjustment. Bed schedules prevent concurrent patients in one bed. Admissions and LOS differences are generated, so the results demonstrate methods rather than institutional performance. Desktop formulas, interactions, workbook portability, and rendering remain untested.
''',encoding='utf-8')

if __name__=='__main__':build()
